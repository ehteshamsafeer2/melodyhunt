from django.apps import AppConfig


class MusicSeperatorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'music_seperator'
